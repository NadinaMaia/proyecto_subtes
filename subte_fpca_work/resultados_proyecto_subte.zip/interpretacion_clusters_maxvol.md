# Interpretación de clusters y MaxVol

## Cómo se formaron los grupos

Las curvas se agruparon dentro de cada tipo de día usando sus scores FPCA. Dos perfiles quedan próximos cuando distribuyen de manera similar su demanda a lo largo del día, aunque sus volúmenes absolutos sean distintos.

## Lectura de los clusters

- **DOM-C1 (Domingo/Feriado)**: 844 perfiles de 80 estaciones. La curva mediana alcanza su pico a las 16:45; concentra 45.2% en mediodía (10–16) y presenta sesgo claro hacia la tarde. El volumen diario mediano es 1,470 pasajeros y la silhouette mediana es 0.623.
- **DOM-C2 (Domingo/Feriado)**: 256 perfiles de 33 estaciones. La curva mediana alcanza su pico a las 18:30; concentra 52.6% en tarde (16–21) y presenta sesgo claro hacia la tarde. El volumen diario mediano es 2,347 pasajeros y la silhouette mediana es 0.389.
- **LAB-C1 (Laborable)**: 612 perfiles de 56 estaciones. La curva mediana alcanza su pico a las 08:30; concentra 37.5% en mediodía (10–16) y presenta balance relativamente parejo entre mañana y tarde. El volumen diario mediano es 7,998 pasajeros y la silhouette mediana es 0.598.
- **LAB-C2 (Laborable)**: 493 perfiles de 53 estaciones. La curva mediana alcanza su pico a las 17:30; concentra 43.4% en tarde (16–21) y presenta sesgo claro hacia la tarde. El volumen diario mediano es 7,996 pasajeros y la silhouette mediana es 0.591.
- **SAB-C1 (Sábado)**: 587 perfiles de 69 estaciones. La curva mediana alcanza su pico a las 12:45; concentra 44.7% en mediodía (10–16) y presenta mayor peso por la tarde. El volumen diario mediano es 2,692 pasajeros y la silhouette mediana es 0.405.
- **SAB-C2 (Sábado)**: 105 perfiles de 15 estaciones. La curva mediana alcanza su pico a las 13:00; concentra 55.9% en mediodía (10–16) y presenta mayor peso por la tarde. El volumen diario mediano es 3,726 pasajeros y la silhouette mediana es 0.410.
- **SAB-C3 (Sábado)**: 373 perfiles de 49 estaciones. La curva mediana alcanza su pico a las 17:15; concentra 42.7% en mediodía (10–16) y presenta sesgo claro hacia la tarde. El volumen diario mediano es 3,940 pasajeros y la silhouette mediana es 0.399.

## Prototipos MaxVol

MaxVol seleccionó perfiles reales que, en conjunto, abarcan un volumen alto en el espacio afín de scores. Deben leerse como casos frontera de la diversidad observada, no como promedios ni como una nueva partición.

- **DOM-P1**: C | CONSTITUCION, 2020, cluster DOM-C1. Pico a las 18:30; mayor concentración en tarde (16–21) (40.1%); volumen diario mediano 2,476. Condición: proyectado fuera de la referencia.
- **DOM-P2**: D | JURAMENTO, 2020, cluster DOM-C2. Pico a las 21:00; mayor concentración en tarde (16–21) (43.0%); volumen diario mediano 502. Condición: proyectado fuera de la referencia.
- **DOM-P3**: H | FACULTAD DE DERECHO, 2018, cluster DOM-C2. Pico a las 18:15; mayor concentración en tarde (16–21) (71.4%); volumen diario mediano 1,923. Condición: parte de la referencia del modelo.
- **DOM-P4**: A | PASCO, 2021, cluster DOM-C1. Pico a las 16:30; mayor concentración en mediodía (10–16) (52.0%); volumen diario mediano 321. Condición: proyectado fuera de la referencia.
- **LAB-P1**: E | CATALINAS, 2026, cluster LAB-C2. Pico a las 17:45; mayor concentración en tarde (16–21) (75.4%); volumen diario mediano 4,684. Condición: proyectado fuera de la referencia, año parcial.
- **LAB-P2**: E | PZA. DE LOS VIRREYES, 2015, cluster LAB-C1. Pico a las 08:15; mayor concentración en mañana (06–10) (58.7%); volumen diario mediano 9,604. Condición: parte de la referencia del modelo.
- **LAB-P3**: E | INDEPENDENCIA, 2019, cluster LAB-C2. Pico a las 12:00; mayor concentración en mediodía (10–16) (40.9%); volumen diario mediano 11,194. Condición: parte de la referencia del modelo.
- **SAB-P1**: A | SAN PEDRITO, 2021, cluster SAB-C2. Pico a las 13:45; mayor concentración en mediodía (10–16) (67.7%); volumen diario mediano 7,741. Condición: proyectado fuera de la referencia.
- **SAB-P2**: C | CONSTITUCION, 2020, cluster SAB-C1. Pico a las 08:00; mayor concentración en mañana (06–10) (41.6%); volumen diario mediano 5,356. Condición: proyectado fuera de la referencia.
- **SAB-P3**: H | FACULTAD DE DERECHO, 2021, cluster SAB-C3. Pico a las 18:00; mayor concentración en tarde (16–21) (60.0%); volumen diario mediano 906. Condición: proyectado fuera de la referencia.
- **SAB-P4**: B | MEDRANO, 2014, cluster SAB-C1. Pico a las 12:00; mayor concentración en mediodía (10–16) (47.7%); volumen diario mediano 5,008. Condición: parte de la referencia del modelo.

## Criterios para la interpretación

- Comparar clusters solamente dentro del mismo segmento de día.
- Usar la silhouette para evaluar cuán nítida es la separación; valores moderados pueden indicar un continuo de formas.
- Revisar especialmente los prototipos de 2020–2021 o de años parciales: pueden representar una ruptura temporal y no un patrón estructural estable.
- Contrastar cada prototipo con su curva y su cobertura antes de asignarle una explicación sustantiva.