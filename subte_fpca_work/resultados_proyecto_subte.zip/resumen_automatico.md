# Resumen automático

- Fuentes aceptadas (procesadas o excluidas por regla): 122 de 122.
- Filas estandarizadas: 139,160,748; tras resolver clave: 137,218,455.
- Filas excluidas por línea ['LINEAPM']: 155,450.
- Intervalos válidos de 15 min y en grilla: 100.00%.
- Días faltantes según calendario evaluado: 28.
- Curvas funcionales segmentadas: 3,270.
- Prototipos MaxVol seleccionados: 11.
- Años parciales detectados: [2026].

## Modelos por segmento

- **Laborable**: 1105 curvas; 2 FPC para 90%; k=2; silhouette=0.529; ARI=1.000.
- **Sábado**: 1065 curvas; 3 FPC para 90%; k=3; silhouette=0.381; ARI=0.996.
- **Domingo/Feriado**: 1100 curvas; 3 FPC para 90%; k=2; silhouette=0.514; ARI=0.998.

- Mayor cambio 2019–2025: C | GENERAL SAN MARTIN, Laborable (1.449).

## Lectura

- Los clusters se interpretan dentro de cada segmento de día.
- Los scores de segmentos distintos no se comparan directamente.
- Los clusters describen forma; el volumen se mantiene como variable separada.
- 2020–2021 y los años parciales se proyectan sobre una referencia estable.
- Silhouette baja puede indicar una estructura continua y no un fallo de FPCA.
- MaxVol selecciona perfiles extremos que abarcan el espacio FPCA; no sustituye a los centroides.
- Días de baja cobertura no deben interpretarse como caídas reales.